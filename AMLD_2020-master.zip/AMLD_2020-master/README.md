# AMLD_2020
This repository contains the assignment for the workshop given at the "Applied Machine Learning Days" on January 26, 2020. The title of the workshop is "Ensemble Techniques: Unity is Strength".
